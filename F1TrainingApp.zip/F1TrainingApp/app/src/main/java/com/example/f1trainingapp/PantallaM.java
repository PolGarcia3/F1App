package com.example.f1trainingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PantallaM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.menu_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // FUNCIONALIDADES DE LOS BOTONES

        // Funcionalidad del boton jugar
        Button botoJugar = findViewById(R.id.botoJugar);

        botoJugar.setOnClickListener(view -> {
            Intent intent = new Intent(this, PantallaD.class);
            startActivity(intent);
        });

        // Funcionalidad del boton configuracion
        Button botoConf = findViewById(R.id.botoConf);

        botoConf.setOnClickListener(view -> {
            Intent intent = new Intent(this, PantallaC.class);
            startActivity(intent);
        });

        // Funcionalidad del boton Ayuda (WEBVIEW)
        Button botoAyuda = findViewById(R.id.botoAyuda);

        botoAyuda.setOnClickListener(view -> {
            Intent intent = new Intent(this, PantallaA.class);
            startActivity(intent);
        });

        // Funcionalidad del botón salir
        Button botoSalir = findViewById(R.id.botoSalir);

        botoSalir.setOnClickListener(view -> {
            // Crear el diálogo de alerta
            new AlertDialog.Builder(this)
                    .setTitle("SALIR")
                    .setMessage("¿Estás seguro de que quieres cerrar la app?")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        finishAffinity();
                    })
                    .setNegativeButton("No", (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .show();
        });
    }
}