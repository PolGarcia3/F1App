package com.example.f1trainingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.graphics.Color;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class PantallaJD2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_jugar);

        // Funcionalidad boton pausa
        //Button botonPausa = findViewById(R.id.botonPausa);
        //
        //botonPausa.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View v) {
        //        Intent intent = new Intent(PantallaJD2.this, PantallaP.class);
        //        startActivity(intent);
        //    }
        //});

        Button botonPausa = findViewById(R.id.botonPausa);

        botonPausa.setOnClickListener(view -> {
            // Infla el layout con el EditText
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_puntuacion, null);

            // Encuentra el EditText en el layout inflado
            EditText input = dialogView.findViewById(R.id.editTextPuntuacion);

            // Crea y muestra el AlertDialog
            new AlertDialog.Builder(this)
                    .setView(dialogView)
                    .setPositiveButton("Aceptar", (dialog, which) -> {
                        String texto = input.getText().toString();
                        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
                    })
                    .show();
        });
    }
}